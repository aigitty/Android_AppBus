package com.example.myapplication_bus;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner locationSpinner;
    private Button goButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        locationSpinner = findViewById(R.id.locationSpinner);
        goButton = findViewById(R.id.goButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.locations_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(adapter);
        locationSpinner.setOnItemSelectedListener(this);

        goButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedPosition = locationSpinner.getSelectedItemPosition();
                switch (selectedPosition) {
                    case 0:
                        startActivity(new Intent(MainActivity2.this, MainActivityMangalore.class));
                        break;
                    case 1:
                        startActivity(new Intent(MainActivity2.this, MainActivityUdupi.class));
                        break;
                    case 2:
                        startActivity(new Intent(MainActivity2.this, MainActivityBelthangady.class));
                        break;
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // Handle item selection if needed
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Handle empty selection if needed
    }
}
