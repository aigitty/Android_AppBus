package com.example.myapplication_bus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.InputType;


public class MainActivitySignin extends AppCompatActivity {
    EditText username, password;
    Button signin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_signin);
        username = findViewById(R.id.username1);
        password = findViewById(R.id.password1);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); // Set input type to password
        signin = findViewById(R.id.signin1);
        DB = new DBHelper(this);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(MainActivitySignin.this, "All fields Required", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUserPass = DB.checkUserPassword(user, pass);
                    if (checkUserPass) {
                        Toast.makeText(MainActivitySignin.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                        startActivity(intent);

                    } else {
                        Toast.makeText(MainActivitySignin.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
            }
        });
    }
}
