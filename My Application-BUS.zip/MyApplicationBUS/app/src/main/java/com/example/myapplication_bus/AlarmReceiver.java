package com.example.myapplication_bus;

import android.app.NotificationChannel;
        import android.app.NotificationManager;
        import android.content.BroadcastReceiver;
        import android.content.Context;
        import android.content.Intent;
        import android.os.Build;

        import androidx.core.app.NotificationCompat;
        import androidx.core.app.NotificationManagerCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {


        // Format the notification message with the bus name and bus time
        String message = "Bus will start it's journey from moodbidri in 10 mins" ;

        // Show the notification
        showNotification(context, message);
    }

    private void showNotification(Context context, String message) {
        // Create a notification channel (required for Android 8.0 and above)
        createNotificationChannel(context);

        // Replace R.drawable.custom_notification_icon with your custom icon resource ID
        int notificationIcon = R.drawable.busalarm;

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "channel_id")
                .setSmallIcon(notificationIcon)
                .setContentTitle("Bus Arrival Time")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // Display the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(0, builder.build());
    }

    private void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel Name";
            String description = "Channel Description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("channel_id", name, importance);
            channel.setDescription(description);

            // Register the channel with the system
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
