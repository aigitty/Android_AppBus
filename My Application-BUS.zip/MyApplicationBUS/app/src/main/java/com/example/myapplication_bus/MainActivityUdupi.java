package com.example.myapplication_bus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Calendar;


public class MainActivityUdupi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_udupi);

        Button nextButton = findViewById(R.id.nextButton);
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        Button button9 = findViewById(R.id.button9);
        Button button10 = findViewById(R.id.button10);
        Button button11 = findViewById(R.id.button11);
        Button button12 = findViewById(R.id.button12);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivityUdupi.this, MainActivityUdupi2.class);
                startActivity(intent);
            }
        });

        setAlarmForButton(8, 0, button1);
        setAlarmForButton(8, 30, button2);
        setAlarmForButton(9, 0, button3);
        setAlarmForButton(9, 30, button4);
        setAlarmForButton(10, 0, button5);
        setAlarmForButton(10, 30, button6);
        setAlarmForButton(11, 0, button7);
        setAlarmForButton(12, 0, button8);
        setAlarmForButton(12, 30, button9);
        setAlarmForButton(13, 0, button10);
        setAlarmForButton(13, 30, button11);
        setAlarmForButton(13, 45, button12);
    }

    private void setAlarmForButton(int hour, int minute, Button button) {
        // Calculate the alarm time 10 minutes prior
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.add(Calendar.MINUTE, -10);

        // Create an intent to trigger the alarm receiver
        Intent intent = new Intent(this, AlarmReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);

        // Get the AlarmManager service
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        // Check if the alarm time has already passed
        long currentTime = System.currentTimeMillis();
        long alarmTime = calendar.getTimeInMillis();

        if (alarmTime <= currentTime) {
            // Alarm time has already passed, disable the button and change its color
            button.setEnabled(false);
            button.setBackgroundColor(getResources().getColor(R.color.button_disabled_color));
        } else {
            // Set the alarm
            if (alarmManager != null) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, alarmTime, pendingIntent);
            }
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!button.isEnabled()) {
                    // Button is disabled, show a toast message indicating that the user has missed the bus
                    Toast.makeText(MainActivityUdupi.this, "You've missed this bus", Toast.LENGTH_SHORT).show();
                } else {
                    setAlarmForButton(hour, minute, button); // Set the alarm for the button's time
                    Toast.makeText(MainActivityUdupi.this, "Alarm set", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
